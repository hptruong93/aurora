import SimpleHTTPServer
import SocketServer
import cgi
import time

PORT_NUMBER = 5555
HOST_NAME = "localhost"

class ServerHandler(SimpleHTTPServer.SimpleHTTPRequestHandler):

    def do_GET(self):
        print(self.headers)
        SimpleHTTPServer.SimpleHTTPRequestHandler.do_GET(self)

    def do_POST(self):
        print("POST")
        print(self.headers)
        print(self.rfile)
        #form = cgi.FieldStorage(
         #   fp=self.rfile,
         #   headers=self.headers,
         #   environ={'REQUEST_METHOD':'POST',
         #            'CONTENT_TYPE':self.headers['Content-Type'],
         #            })
        #print("Dumping list")
        #for item in form.list:
        #    print(item)
        SimpleHTTPServer.SimpleHTTPRequestHandler.do_GET(self)


if __name__ == '__main__':
        server_class = SimpleHTTPServer
        httpd = server_class((HOST_NAME, PORT_NUMBER), ServerHandler)
        print time.asctime(), "Server Starts - %s:%s" % (HOST_NAME, PORT_NUMBER)
        try:
                httpd.serve_forever()
        except KeyboardInterrupt:
                pass
        httpd.server_close()
        print time.asctime(), "Server Stops - %s:%s" % (HOST_NAME, PORT_NUMBER)
